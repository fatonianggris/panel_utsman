<?php

class PresenceModel extends CI_Model {

    private $table_schoolyear = 'tahun_ajaran';
    private $table_present = 'absensi_pegawai';

    public function get_schoolyear() {
        $this->db->select('*');
        $this->db->group_by('tahun_awal');
        $this->db->order_by('tahun_awal', 'ASC');

        $sql = $this->db->get($this->table_schoolyear);
        return $sql->result();
    }

    public function get_present_by_id($id_pegawai = '') {
        $this->db->select("a.*,
                            p.nama_lengkap,
                            p.foto_pegawai_thumb,
                            p.nip,
                            DATE(a.inserted_at) AS tgl_post,
                            DATE_FORMAT(a.inserted_at, '%d/%m/%Y') AS tgl_format,
                            DATE_FORMAT(a.updated_at, '%d/%m/%Y') AS tgl_update,,
                            ta.tahun_awal,
                            ta.tahun_akhir");

        $this->db->from('absensi_pegawai a');

        $this->db->join('pegawai p', 'a.id_pegawai = p.id_pegawai', 'left');
        $this->db->join('tahun_ajaran ta', 'a.th_ajaran = ta.id_tahun_ajaran', 'left');

        $this->db->where('a.id_pegawai', $id_pegawai);
        $this->db->order_by('a.inserted_at', 'ASC');

        $sql = $this->db->get();
        return $sql->result();
    }

    public function get_present_all($level_jabatan = '', $level_tingkat = '') {

        if ($level_jabatan == 0) {

            $this->db->select("a.*,
                            p.nama_lengkap,
                            p.foto_pegawai_thumb,
                            p.nip,
                            DATE(a.inserted_at) AS tgl_post,
                            DATE_FORMAT(a.inserted_at, '%d/%m/%Y') AS tgl_format,
                            DATE_FORMAT(a.updated_at, '%d/%m/%Y') AS tgl_update,,
                            ta.tahun_awal,
                            ta.tahun_akhir");

            $this->db->from('absensi_pegawai a');

            $this->db->join('pegawai p', 'a.id_pegawai = p.id_pegawai', 'left');
            $this->db->join('tahun_ajaran ta', 'a.th_ajaran = ta.id_tahun_ajaran', 'left');
        } else {

            $this->db->select("a.*,
                            p.nama_lengkap,
                            p.foto_pegawai_thumb,
                            p.nip,
                            DATE(a.inserted_at) AS tgl_post,
                            DATE_FORMAT(a.inserted_at, '%d/%m/%Y') AS tgl_format,
                            DATE_FORMAT(a.updated_at, '%d/%m/%Y') AS tgl_update,,
                            ta.tahun_awal,
                            ta.tahun_akhir");

            $this->db->from('absensi_pegawai a');

            $this->db->join('pegawai p', 'a.id_pegawai = p.id_pegawai', 'left');
            $this->db->join('tahun_ajaran ta', 'a.th_ajaran = ta.id_tahun_ajaran', 'left');
            $this->db->where('p.level_tingkat', $level_tingkat);
        }

        $this->db->order_by('a.inserted_at', 'ASC');

        $sql = $this->db->get();
        return $sql->result();
    }

    public function get_employe_present_id($id_present = '') {
        $this->db->select("a.*, ta.semester,
                                p.nama_lengkap,
                                p.nip,
                                p.level_tingkat,
                                CONCAT(ta.tahun_awal,'/',ta.tahun_akhir) AS tahun_ajaran, 
                                DATE(a.inserted_at) AS tgl_asli,
                                DATE_FORMAT(a.inserted_at, '%d/%m/%Y') AS tgl_post,
                                DATE_FORMAT(a.updated_at, '%d/%m/%Y') AS tgl_update,                          
                         ");
        $this->db->from('absensi_pegawai a');

        $this->db->join('pegawai p', 'p.id_pegawai = a.id_pegawai', 'left');
        $this->db->join('tahun_ajaran ta', 'a.th_ajaran = ta.id_tahun_ajaran', 'left');
        $this->db->where('a.id_absensi_pegawai', $id_present);

        $this->db->order_by('a.inserted_at', 'ASC');

        $sql = $this->db->get();
        return $sql->result();
    }

    //-----------------------------------------------------------------------//
//
}

?>